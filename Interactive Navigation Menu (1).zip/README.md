
  # Interactive Navigation Menu

  This is a code bundle for Interactive Navigation Menu. The original project is available at https://www.figma.com/design/2saY9TdbcBvY1IfNVPSZyT/Interactive-Navigation-Menu.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  